/*test_gdb.c -- for a simple test of gdb*/

#include <stdio.h>

struct Data {
	int x;
};

int main()
{
	struct Data *p = NULL;

	printf("%d\n", p->x);
	return 0;
}
