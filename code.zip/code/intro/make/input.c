/*input.c*/

#include <stdio.h>

int input_integer(int *input)
{

	printf("Input an integer: ");
	scanf("%d", input);
	return 0;
}
