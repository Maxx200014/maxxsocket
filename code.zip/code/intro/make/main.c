#include <stdio.h>

extern int input_integer(int *);
extern int output_integer(int *);

int main()
{
	int intval;

	input_integer(&intval);
	output_integer(&intval);
	return 0;
}
