/*output.c*/

#include <stdio.h>

int output_integer(int *output)
{

	printf("The input integer is: %d\n", *output);
	return 0;
}
